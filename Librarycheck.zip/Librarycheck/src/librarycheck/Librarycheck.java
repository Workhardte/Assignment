/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarycheck;

import java.util.Scanner;


public class Librarycheck {

    public static void main(String[] args) {
         int num;
        String name;
        String book;
        String book1;
        String book2;
        
        System.out.println("What's your name? ");
        Scanner a1=new Scanner(System.in);
        name=a1.nextLine();
        for(int x=1;x<=10;x++){
        
       System.out.println("input the number of books you want to check");
        Scanner a=new Scanner(System.in);
        num=a.nextInt();
        
         if(num<=3){
            System.out.println(name+" You're allowed to checkout 3 Books "); 
            System.out.println("input a book 1");
            Scanner b=new Scanner(System.in);
            book=b.nextLine();
            System.out.println("input a book 2");
            Scanner c=new Scanner(System.in);
            book1=c.nextLine();
            System.out.println("input a book 3");
            Scanner d=new Scanner(System.in);
            book2=d.nextLine();
            System.out.println(name+" The books You Checked Out At This Time:");
            System.out.println("The book 1 is "+book);
            System.out.println("The book 2 is "+book1);
            System.out.println("The book 3 is "+book2);
            System.out.println("We hope you enjoyed it. KEEP LEARNING IS THE KEY OF SUCCESS!!!");
            break;
            
       }
            else{
                System.out.println("Invalid number");
                
            }
    }
    
}
}
